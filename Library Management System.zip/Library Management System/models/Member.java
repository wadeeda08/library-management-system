/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.models;

/**
 *
 * @author unknown
 */
public class Member {

    private int memberId;
    private String memberName;
    private String memberEmail;
    private String memberPhone;

    public Member(int memberId, String memberName,
                  String memberEmail, String memberPhone) {

        this.memberId = memberId;
        this.memberName = memberName;
        this.memberEmail = memberEmail;
        this.memberPhone = memberPhone;
    }

    public int getMemberId() {
        return memberId;
    }

    public String getMemberName() {
        return memberName;
    }

    public String getMemberEmail() {
        return memberEmail;
    }

    public String getMemberPhone() {
        return memberPhone;
    }

    public void displayMember() {

        System.out.println("Member ID: " + memberId);
        System.out.println("Member Name: " + memberName);
        System.out.println("Email: " + memberEmail);
        System.out.println("Phone: " + memberPhone);
    }
}