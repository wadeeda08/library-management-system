/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;
import javax.swing.*;
/**
 *
 * @author unknown
 */

public class RecordScreen extends JFrame {

    public RecordScreen() {

        JOptionPane.showMessageDialog(null,
                "📋 LIBRARY RECORD\n\n" +

                "Issued Books:\n" +
                "ID: 101 | Java Programming | Student 501\n" +
                "ID: 102 | Data Structures | Student 502\n\n" +

                "Returned Books:\n" +
                "ID: 102 | Data Structures | Returned\n\n" +

                "Total Books: 4\n" +
                "Issued: 1\n" +
                "Available: 3"
        );

        dispose();
    }
}