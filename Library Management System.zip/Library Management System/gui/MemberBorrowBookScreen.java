/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;
import javax.swing.*;

/**
 *
 * @author unknown
 */

public class MemberBorrowBookScreen extends JFrame {

    public MemberBorrowBookScreen() {

        String id = JOptionPane.showInputDialog("Enter Book ID to Borrow:");

        if (id == null) return;

        if (id.equals("101")) {

            JOptionPane.showMessageDialog(null,
                    "📤 BOOK BORROWED SUCCESSFULLY\n\n" +
                    "📘 Java Programming\n" +
                    "👨‍🏫 James Gosling\n" +
                    "📊 Status: Issued to You\n\n" +
                    "⏳ Return within 14 days"
            );

        } else if (id.equals("103")) {

            JOptionPane.showMessageDialog(null,
                    "📤 BOOK BORROWED SUCCESSFULLY\n\n" +
                    "📘 Database Systems\n" +
                    "👨‍🏫 Abraham Silberschatz\n" +
                    "📊 Status: Issued to You\n\n" +
                    "⏳ Return within 14 days"
            );

        } else {

            JOptionPane.showMessageDialog(null,
                    "❌ Book not available for borrowing!\nTry available books only."
            );
        }

        dispose();
    }
}