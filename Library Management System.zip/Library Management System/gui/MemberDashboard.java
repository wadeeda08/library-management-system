
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author unknown
 */
public class MemberDashboard extends JFrame {

    public MemberDashboard() {

        setTitle("Digital Library Dashboard");
        setSize(1000, 620);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(null);

        // BACKGROUND COLOR
        getContentPane().setBackground(new Color(18, 24, 38));

        Font font = new Font("Arial", Font.BOLD, 15);

        // ================= TITLE =================

        JLabel title = new JLabel("DIGITAL LIBRARY MEMBER PANEL");
        title.setBounds(240, 25, 600, 40);

        title.setForeground(Color.WHITE);

        title.setFont(new Font("Arial", Font.BOLD, 30));

        add(title);

        // ================= BUTTONS =================

        JButton searchBtn =
                createButton("🔍 Search Books",
                        new Color(52,152,219),
                        font);

        JButton viewBtn =
                createButton("📚 View All Books",
                        new Color(155,89,182),
                        font);

        JButton availableBtn =
                createButton("📖 Available Books",
                        new Color(46,204,113),
                        font);

        JButton issuedBtn =
                createButton("📋 My Issued Books",
                        new Color(241,196,15),
                        font);

        JButton borrowBtn =
                createButton("📤 Borrow Book",
                        new Color(26,188,156),
                        font);

        JButton returnBtn =
                createButton("📥 Return Book",
                        new Color(230,126,34),
                        font);

        JButton logoutBtn =
                createButton("🚪 Logout",
                        new Color(231,76,60),
                        font);

        // ================= FABULOUS ALIGNMENT =================

        searchBtn.setBounds(60,120,250,90);

        viewBtn.setBounds(380,100,260,90);

        availableBtn.setBounds(700,140,240,90);

        issuedBtn.setBounds(130,300,270,90);

        borrowBtn.setBounds(450,260,240,90);

        returnBtn.setBounds(730,360,220,90);

        logoutBtn.setBounds(390,450,220,80);

        // ================= ACTIONS =================

        searchBtn.addActionListener(e -> new MemberSearchBookScreen());

        viewBtn.addActionListener(e -> new MemberViewAllBooksScreen());

        availableBtn.addActionListener(e -> new MemberViewAvailableBooksScreen());

        issuedBtn.addActionListener(e -> new MemberIssuedBooksScreen());

        borrowBtn.addActionListener(e -> new MemberBorrowBookScreen());

        returnBtn.addActionListener(e -> new MemberReturnBookScreen());

        logoutBtn.addActionListener(e -> {

            dispose();

            new LoginScreen();
        });

        // ================= ADD BUTTONS =================

        add(searchBtn);

        add(viewBtn);

        add(availableBtn);

        add(issuedBtn);

        add(borrowBtn);

        add(returnBtn);

        add(logoutBtn);

        setVisible(true);
    }

    // ================= BUTTON STYLE =================

    private JButton createButton(String text,
                                 Color color,
                                 Font font) {

        JButton btn = new JButton(text);

        btn.setBackground(color);

        btn.setForeground(Color.WHITE);

        btn.setFont(font);

        btn.setFocusPainted(false);

        btn.setBorder(
                BorderFactory.createLineBorder(
                        Color.WHITE,
                        3
                )
        );

        return btn;
    }
}