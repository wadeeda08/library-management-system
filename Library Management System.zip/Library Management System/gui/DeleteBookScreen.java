/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author unknown
 */    
package library.gui;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;

public class DeleteBookScreen extends JFrame {

    public DeleteBookScreen() {

        String id = JOptionPane.showInputDialog("Enter Book ID to Delete:");

        if (id == null || id.trim().isEmpty()) {
            return;
        }

        deleteBook(id.trim());

        dispose();
    }

    // REAL DELETE FUNCTION
    private void deleteBook(String id) {

        File file = new File("books.txt");

        if (!file.exists()) {
            JOptionPane.showMessageDialog(null, "No book file found!");
            return;
        }

        ArrayList<String> updatedBooks = new ArrayList<>();
        boolean found = false;

        try {

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;

            while ((line = reader.readLine()) != null) {

                String[] data = line.split(",");

                if (data.length == 3) {

                    // If ID matches → skip (delete it)
                    if (data[0].equals(id)) {
                        found = true;
                        continue;
                    }

                    updatedBooks.add(line);
                }
            }

            reader.close();

            // Rewrite file without deleted book
            FileWriter writer = new FileWriter(file);

            for (String book : updatedBooks) {
                writer.write(book + "\n");
            }

            writer.close();

            if (found) {

                JOptionPane.showMessageDialog(null,
                        "🗑 BOOK DELETED SUCCESSFULLY\n\nDeleted Book ID: " + id
                );

            } else {

                JOptionPane.showMessageDialog(null,
                        "❌ Book not found!");
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null,
                    "Error deleting book!");
        }
    }
}