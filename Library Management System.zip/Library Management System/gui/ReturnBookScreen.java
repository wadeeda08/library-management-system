/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;
import javax.swing.*;

/**
 *
 * @author unknown
 */
public class ReturnBookScreen extends JFrame {

    public ReturnBookScreen() {

        String id = JOptionPane.showInputDialog("Enter Book ID to Return:");

        if (id == null) return;

        if (id.equals("102")) {

            JOptionPane.showMessageDialog(null,
                    "📥 BOOK RETURNED\n\n" +
                    "Book: Data Structures\n" +
                    "Status: Now Available"
            );

        } else {

            JOptionPane.showMessageDialog(null,
                    "❌ This book is not marked as issued");
        }

        dispose();
    }
}