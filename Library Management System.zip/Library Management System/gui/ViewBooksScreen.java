/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package library.gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;

/**
 *
 * @author unknown
 */
public class ViewBooksScreen extends JFrame {

    JTable table;
    DefaultTableModel model;

    public ViewBooksScreen() {

        setTitle("📚 View Books");
        setSize(750, 450);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Table columns
        String[] columns = {"Book ID", "Book Name", "Author"};

        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);

        table.setRowHeight(28);
        table.setFont(new Font("Arial", Font.PLAIN, 14));

        JScrollPane pane = new JScrollPane(table);
        add(pane, BorderLayout.CENTER);

        loadBooks();

        setVisible(true);
    }

    // Load books from file
    public void loadBooks() {

        try {
            //file handling

            File file = new File("books.txt");

            // Create file if not exists
            if (!file.exists()) {
                file.createNewFile();
            }

            // Add default data ONLY if file is empty
            if (file.length() == 0) {

                FileWriter writer = new FileWriter(file);

                writer.write("101,Java Programming,James Gosling\n");
                writer.write("102,Object Oriented Programming,Bjarne Stroustrup\n");
                writer.write("103,Data Structures,Mark Allen Weiss\n");

                writer.close();
            }

            // Clear table before loading fresh data
            model.setRowCount(0);

            // Read file and load into table
            BufferedReader reader = new BufferedReader(new FileReader(file));

            String line;

            while ((line = reader.readLine()) != null) {

                String[] data = line.split(",");

                if (data.length == 3) {

                    model.addRow(new Object[]{
                            data[0],
                            data[1],
                            data[2]
                    });
                }
            }

            reader.close();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(this,
                    "Error loading books!"
            );
        }
    }

    // 🔥 IMPORTANT: call this whenever Add/Delete happens
    public void refreshTable() {
        loadBooks();
    }
}