/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author unknown
 */

package library.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginScreen extends JFrame implements ActionListener {

    JTextField userField;
    JPasswordField passField;

    JButton adminButton;
    JButton memberButton;

    public LoginScreen() {

        setTitle("Library Login");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(20, 20, 40));

        JLabel title = new JLabel("LIBRARY MANAGEMENT SYSTEM");
        title.setBounds(120, 40, 500, 50);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 30));

        JLabel user = new JLabel("Username");
        user.setBounds(150, 140, 100, 30);
        user.setForeground(Color.WHITE);

        userField = new JTextField();
        userField.setBounds(280, 140, 200, 30);

        JLabel pass = new JLabel("Password");
        pass.setBounds(150, 200, 100, 30);
        pass.setForeground(Color.WHITE);

        passField = new JPasswordField();
        passField.setBounds(280, 200, 200, 30);

        adminButton = new JButton("ADMIN LOGIN");
        adminButton.setBounds(160, 300, 170, 50);

        memberButton = new JButton("MEMBER LOGIN");
        memberButton.setBounds(360, 300, 170, 50);

        JButton[] buttons = {adminButton, memberButton};

        for (JButton b : buttons) {

            b.setBackground(new Color(120, 80, 255));
            b.setForeground(Color.WHITE);
            b.setFont(new Font("Arial", Font.BOLD, 16));

            b.addActionListener(this);

            panel.add(b);
        }

        panel.add(title);
        panel.add(user);
        panel.add(userField);
        panel.add(pass);
        panel.add(passField);

        add(panel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        String username = userField.getText();
        String password = new String(passField.getPassword());

        // 🔐 ADMIN LOGIN CHECK
        if (e.getSource() == adminButton) {

            if (username.equals("Deed") && password.equals("877")) {

                JOptionPane.showMessageDialog(this,
                        "Admin Login Successful!");

                new AdminDashboard();
                dispose();

            } else {

                JOptionPane.showMessageDialog(this,
                        "Invalid Admin Username or Password!",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }

        // 👤 MEMBER LOGIN CHECK
        if (e.getSource() == memberButton) {

            if (username.equals("member") && password.equals("0000")) {

                JOptionPane.showMessageDialog(this,
                        "Member Login Successful!");

                new MemberDashboard();
                dispose();

            } else {

                JOptionPane.showMessageDialog(this,
                        "Invalid Member Username or Password!",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}