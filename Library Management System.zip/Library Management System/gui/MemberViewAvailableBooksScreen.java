/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;
import javax.swing.*;

/**
 *
 * @author unknown
 */
public class MemberViewAvailableBooksScreen extends JFrame {

    public MemberViewAvailableBooksScreen() {

        JOptionPane.showMessageDialog(null,
                "📖 AVAILABLE BOOKS\n\n" +

                "🟢 101 | Java Programming | James Gosling\n" +
                "🟢 103 | Database Systems | Abraham Silberschatz\n" +
                "🟢 104 | Operating Systems | Galvin\n\n" +

                "🔴 NOT AVAILABLE:\n" +
                "102 | Data Structures (Issued)"
        );

        dispose();
    }
}