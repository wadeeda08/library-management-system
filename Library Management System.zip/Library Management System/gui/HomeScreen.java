/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author unknown
 */

public class HomeScreen extends JFrame implements ActionListener {

    JButton loginButton;

    public HomeScreen() {

        setTitle("Home");
        setSize(800,500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(30,30,50));
        panel.setLayout(null);

        JLabel heading = new JLabel("WELCOME TO DIGITAL LIBRARY");
        heading.setBounds(160,120,500,50);
        heading.setForeground(Color.WHITE);
        heading.setFont(new Font("Poppins", Font.BOLD,30));

        loginButton = new JButton("LOGIN");

        loginButton.setBounds(300,260,180,50);
        loginButton.setBackground(new Color(130,90,255));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFont(new Font("Arial", Font.BOLD,18));

        loginButton.addActionListener(this);

        panel.add(heading);
        panel.add(loginButton);

        add(panel);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        dispose();

        new LoginScreen();
    }
}