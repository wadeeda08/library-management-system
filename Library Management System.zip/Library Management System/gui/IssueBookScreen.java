
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author unknown
 */
package library.gui;

import javax.swing.*;

public class IssueBookScreen extends JFrame {

    public IssueBookScreen() {

        String id = JOptionPane.showInputDialog("Enter Book ID to Issue:");

        if (id == null) return;

        if (id.equals("101")) {

            JOptionPane.showMessageDialog(null,
                    "📤 BOOK ISSUED\n\n" +
                    "Book: Java Programming\n" +
                    "To: Student ID 501\n" +
                    "Status: Issued"
            );

        } else if (id.equals("102")) {

            JOptionPane.showMessageDialog(null,
                    "📤 BOOK ISSUED\n\n" +
                    "Book: Data Structures\n" +
                    "To: Student ID 502\n" +
                    "Status: Issued"
            );

        } else {

            JOptionPane.showMessageDialog(null,
                    "❌ Book not available for issue");
        }

        dispose();
    }
}