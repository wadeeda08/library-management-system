

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author unknown
 */

package library.gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;

public class ViewMembersScreen extends JFrame {

    JTable table;
    DefaultTableModel model;

    public ViewMembersScreen() {

        setTitle("👥 View Members");
        setSize(700, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ================= HEADER =================
        JLabel header = new JLabel("📚 Library Members", JLabel.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 22));
        header.setOpaque(true);
        header.setBackground(new Color(0, 102, 204));
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(700, 60));

        add(header, BorderLayout.NORTH);

        // ================= TABLE =================
        String[] columns = {"Member ID", "Member Name"};

        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);

        table.setRowHeight(25);
        table.setFont(new Font("Arial", Font.PLAIN, 14));

        JScrollPane pane = new JScrollPane(table);
        add(pane, BorderLayout.CENTER);

        loadMembers();

        setVisible(true);
    }

    // ================= LOAD MEMBERS =================
    private void loadMembers() {

        try {

            File file = new File("members.txt");

            // Create file if not exists
            if (!file.exists()) {
                file.createNewFile();
            }

            // If empty file → add default members
            if (file.length() == 0) {

                FileWriter writer = new FileWriter(file);

                writer.write("1,Wadeeda\n");
                writer.write("2,Maryam\n");
                writer.write("3,Hina\n");
                writer.write("4,Ali\n");
                writer.write("5,Ahmed\n");

                writer.close();
            }

            model.setRowCount(0);

            BufferedReader reader = new BufferedReader(new FileReader(file));

            String line;

            while ((line = reader.readLine()) != null) {

                String[] data = line.split(",");

                if (data.length == 2) {

                    model.addRow(new Object[]{
                            data[0],
                            data[1]
                    });
                }
            }

            reader.close();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(this,
                    "Error loading members!");
        }
    }
}