/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
/**
 *
 * @author unknown
 */
public class SearchBookScreen extends JFrame {

    JTextField searchField;
    JTable table;
    DefaultTableModel model;

    public SearchBookScreen() {

        setTitle("🔍 Search Book");
        setSize(850, 450);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ================= TOP PANEL =================
        JPanel topPanel = new JPanel();
        topPanel.setBackground(new Color(25, 118, 210));

        JLabel label = new JLabel("Enter Book ID:");
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Arial", Font.BOLD, 16));

        searchField = new JTextField(15);

        JButton searchBtn = new JButton("Search");
        JButton clearBtn = new JButton("Clear");

        searchBtn.setBackground(Color.WHITE);
        clearBtn.setBackground(Color.WHITE);

        topPanel.add(label);
        topPanel.add(searchField);
        topPanel.add(searchBtn);
        topPanel.add(clearBtn);

        add(topPanel, BorderLayout.NORTH);

        // ================= TABLE =================
        String[] columns = {"Book ID", "Book Name", "Author"};

        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);

        table.setRowHeight(28);
        table.setFont(new Font("Arial", Font.PLAIN, 14));

        JScrollPane pane = new JScrollPane(table);
        add(pane, BorderLayout.CENTER);

        // ================= ACTIONS =================
        searchBtn.addActionListener(e -> searchBook());

        clearBtn.addActionListener(e -> clearTable());

        setVisible(true);
    }

    // ================= SEARCH ONLY =================
    private void searchBook() {

        String id = searchField.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter Book ID!");
            return;
        }

        model.setRowCount(0); // clear table first

        try {

            File file = new File("books.txt");

            if (!file.exists()) {
                JOptionPane.showMessageDialog(this, "No books available!");
                return;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));

            String line;
            boolean found = false;

            while ((line = reader.readLine()) != null) {

                String[] data = line.split(",");

                if (data.length == 3 && data[0].equals(id)) {

                    model.addRow(new Object[]{
                            data[0],
                            data[1],
                            data[2]
                    });

                    found = true;
                    break;
                }
            }

            reader.close();

            if (!found) {
                JOptionPane.showMessageDialog(this, "❌ Book Not Found!");
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(this,
                    "Error searching book!");
        }
    }

    // ================= CLEAR TABLE =================
    private void clearTable() {
        model.setRowCount(0);
        searchField.setText("");
    }
}