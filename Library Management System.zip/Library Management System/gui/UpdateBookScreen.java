
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author unknown
 */

package library.gui;

import javax.swing.*;

public class UpdateBookScreen extends JFrame {

    public UpdateBookScreen() {

        String id = JOptionPane.showInputDialog("Enter Book ID to Update:");

        if (id == null) return;

        if (id.equals("101")) {

            JOptionPane.showMessageDialog(null,
                    "📘 UPDATE BOOK\n\n" +
                    "Old Data:\nJava Programming - James Gosling\n\n" +
                    "New Data Example:\nJava Advanced - James Gosling"
            );

        } else if (id.equals("102")) {

            JOptionPane.showMessageDialog(null,
                    "📘 UPDATE BOOK\n\n" +
                    "Old Data:\nData Structures - Mark Allen Weiss\n\n" +
                    "New Data Example:\nAdvanced Data Structures - Weiss"
            );

        } else {

            JOptionPane.showMessageDialog(null,
                    "❌ Book not found!");
        }

        dispose();
    }
}