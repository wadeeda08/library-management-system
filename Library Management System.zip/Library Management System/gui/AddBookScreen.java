/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;

/**
 *
 * @author unknown
 */
public class AddBookScreen extends JFrame {

    public AddBookScreen() {

        setTitle("Add New Book");

        setSize(600, 450);

        setLocationRelativeTo(null);

        setLayout(null);

        getContentPane().setBackground(
                new Color(30, 39, 46)
        );

        // ===== TITLE =====
        JLabel title =
                new JLabel("📚 ADD NEW BOOK");

        title.setBounds(170, 20, 300, 40);

        title.setFont(
                new Font("Arial", Font.BOLD, 28)
        );

        title.setForeground(Color.WHITE);

        add(title);

        // ===== LABELS =====
        JLabel idLabel =
                new JLabel("Book ID");

        JLabel nameLabel =
                new JLabel("Book Name");

        JLabel authorLabel =
                new JLabel("Author Name");

        idLabel.setBounds(80, 100, 120, 30);
        nameLabel.setBounds(80, 160, 120, 30);
        authorLabel.setBounds(80, 220, 120, 30);

        Font labelFont =
                new Font("Arial", Font.BOLD, 18);

        idLabel.setFont(labelFont);
        nameLabel.setFont(labelFont);
        authorLabel.setFont(labelFont);

        idLabel.setForeground(Color.WHITE);
        nameLabel.setForeground(Color.WHITE);
        authorLabel.setForeground(Color.WHITE);

        add(idLabel);
        add(nameLabel);
        add(authorLabel);

        // ===== TEXT FIELDS =====
        JTextField idField =
                new JTextField();

        JTextField nameField =
                new JTextField();

        JTextField authorField =
                new JTextField();

        idField.setBounds(220, 100, 250, 35);
        nameField.setBounds(220, 160, 250, 35);
        authorField.setBounds(220, 220, 250, 35);

        Font textFont =
                new Font("Arial", Font.PLAIN, 16);

        idField.setFont(textFont);
        nameField.setFont(textFont);
        authorField.setFont(textFont);

        add(idField);
        add(nameField);
        add(authorField);

        // ===== BUTTON =====
        JButton addButton =
                new JButton("ADD BOOK");

        addButton.setBounds(200, 310, 180, 45);

        addButton.setFont(
                new Font("Arial", Font.BOLD, 18)
        );

        addButton.setBackground(
                new Color(0, 184, 148)
        );

        addButton.setForeground(Color.WHITE);

        add(addButton);

        // ===== BUTTON ACTION =====
        addButton.addActionListener(e -> {

            try {

                String id =
                        idField.getText();

                String name =
                        nameField.getText();

                String author =
                        authorField.getText();

                // Validation
                if (id.isEmpty() ||
                    name.isEmpty() ||
                    author.isEmpty()) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Please Fill All Fields!"
                    );

                    return;
                }

                // Save Data
                FileWriter writer =
                        new FileWriter(
                                "books.txt",
                                true
                        );

                writer.write(
                        id + "," +
                        name + "," +
                        author + "\n"
                );

                writer.close();

                JOptionPane.showMessageDialog(
                        this,
                        "✅ Book Added Successfully!"
                );

                // Clear Fields
                idField.setText("");
                nameField.setText("");
                authorField.setText("");

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        this,
                        "Error Saving Book!"
                );
            }
        });

        setVisible(true);
    }
}