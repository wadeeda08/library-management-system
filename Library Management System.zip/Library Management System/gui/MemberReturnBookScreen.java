/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;

/**
 *
 * @author unknown
 */

import javax.swing.*;

public class MemberReturnBookScreen extends JFrame {

    public MemberReturnBookScreen() {

        String id = JOptionPane.showInputDialog("Enter Book ID to Return:");

        if (id == null) return;

        if (id.equals("102")) {

            JOptionPane.showMessageDialog(null,
                    "📥 BOOK RETURNED SUCCESSFULLY\n\n" +
                    "Book: Data Structures\n" +
                    "Status: Now Available\n" +
                    "Thank you for returning on time!"
            );

        } else if (id.equals("101") || id.equals("103") || id.equals("104")) {

            JOptionPane.showMessageDialog(null,
                    "⚠ This book was not issued to you!"
            );

        } else {

            JOptionPane.showMessageDialog(null,
                    "❌ Invalid Book ID");
        }

        dispose();
    }
}