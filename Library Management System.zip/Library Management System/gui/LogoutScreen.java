/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author unknown
 */

public class LogoutScreen extends JFrame implements ActionListener {

    JButton yes, no;

    public LogoutScreen() {

        setTitle("Logout");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel p = new JPanel();
        p.setLayout(null);
        p.setBackground(new Color(44, 62, 80));

        JLabel l = new JLabel("Do you want to logout?");
        l.setBounds(100, 30, 250, 30);
        l.setForeground(Color.WHITE);
        l.setFont(new Font("Arial", Font.BOLD, 16));

        yes = new JButton("YES");
        no = new JButton("NO");

        yes.setBounds(70, 90, 100, 40);
        no.setBounds(200, 90, 100, 40);

        yes.setBackground(new Color(231, 76, 60));
        yes.setForeground(Color.WHITE);

        no.setBackground(new Color(46, 204, 113));
        no.setForeground(Color.WHITE);

        yes.addActionListener(this);
        no.addActionListener(this);

        p.add(l);
        p.add(yes);
        p.add(no);

        add(p);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == yes) {

            dispose(); // close logout screen

            // 🔥 BACK TO MAIN LOGIN SCREEN
            new LoginScreen();
        }

        if (e.getSource() == no) {

            dispose(); // just close popup
        }
    }
}