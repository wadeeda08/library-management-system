/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;
import javax.swing.*;
/**
 *
 * @author unknown
 */

public class MemberIssuedBooksScreen extends JFrame {

    public MemberIssuedBooksScreen() {

        JOptionPane.showMessageDialog(null,
                "📋 MY ISSUED BOOKS\n\n" +

                "👤 Student ID: 501\n\n" +
                "📘 Book: Data Structures\n" +
                "👨‍🏫 Author: Mark Allen Weiss\n" +
                "📅 Issued: 10-May-2026\n" +
                "⏳ Due: 25-May-2026\n\n" +
                "⚠ Please return on time to avoid fine"
        );

        dispose();
    }
}