/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author unknown
 */

public class EditProfileScreen extends JFrame {

    JTextField nameField;
    JTextField emailField;

    public EditProfileScreen() {

        setTitle("Edit Profile");
        setSize(400,300);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel n = new JLabel("Name:");
        n.setBounds(50,50,100,30);

        nameField = new JTextField();
        nameField.setBounds(150,50,180,30);

        JLabel e = new JLabel("Email:");
        e.setBounds(50,100,100,30);

        emailField = new JTextField();
        emailField.setBounds(150,100,180,30);

        JButton save = new JButton("SAVE");
        save.setBounds(120,180,120,40);

        save.addActionListener(a ->
                JOptionPane.showMessageDialog(this, "Profile Updated")
        );

        panel.add(n);
        panel.add(nameField);
        panel.add(e);
        panel.add(emailField);
        panel.add(save);

        add(panel);

        setVisible(true);
    }
}