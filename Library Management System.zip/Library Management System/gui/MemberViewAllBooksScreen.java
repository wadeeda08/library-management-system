/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;
import javax.swing.*;

/**
 *
 * @author unknown
 */



public class MemberViewAllBooksScreen extends JFrame {

    public MemberViewAllBooksScreen() {

        JOptionPane.showMessageDialog(null,
                "📚 ALL LIBRARY BOOKS\n\n" +

                "🆔 101 | Java Programming | James Gosling | Available\n" +
                "🆔 102 | Data Structures | Mark Allen Weiss | Issued\n" +
                "🆔 103 | Database Systems | Abraham Silberschatz | Available\n" +
                "🆔 104 | Operating Systems | Galvin | Available"
        );

        dispose();
    }
}