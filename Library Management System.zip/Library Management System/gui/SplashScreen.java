/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author unknown
 */
public class SplashScreen extends JFrame {

    public SplashScreen() {

        setTitle("Library Management System");
        setSize(700,400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(25,25,45));
        panel.setLayout(null);

        JLabel title = new JLabel("LIBRARY MANAGEMENT SYSTEM");
        title.setBounds(120,130,500,50);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Poppins", Font.BOLD, 28));

        JLabel subtitle = new JLabel(" Wadeeda  ,  Maryam   ,  Hina  ");
        subtitle.setBounds(220,190,300,30);
        subtitle.setForeground(Color.LIGHT_GRAY);
        subtitle.setFont(new Font("Arial", Font.PLAIN,20));

        panel.add(title);
        panel.add(subtitle);

        add(panel);
        setVisible(true);

        try {

            Thread.sleep(4000);

            dispose();

            new HomeScreen();

        } catch(Exception e) {

            System.out.println(e);
        }
    }

    public static void main(String[] args) {

        new SplashScreen();
    }
}