/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author unknown
 */
public class AdminDashboard extends JFrame {

    public AdminDashboard() {

        setTitle("Library Admin Dashboard");

        setSize(1000, 650);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // ================= PANEL =================

        JPanel panel = new JPanel();

        panel.setLayout(null);

        panel.setBackground(new Color(34, 47, 62));

        Font font = new Font(
                "Arial",
                Font.BOLD,
                15
        );

        // ================= TITLE =================

        JLabel title = new JLabel(
                "DIGITAL LIBRARY ADMIN PANEL"
        );

        title.setBounds(250, 20, 500, 40);

        title.setForeground(Color.WHITE);

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        28
                )
        );

        panel.add(title);

        // ================= BUTTONS =================

        JButton addBook =
                createButton(
                        "Add Book",
                        new Color(46, 204, 113),
                        font
                );

        JButton viewBook =
                createButton(
                        "View Books",
                        new Color(52, 152, 219),
                        font
                );

        JButton searchBook =
                createButton(
                        "Search Book",
                        new Color(241, 196, 15),
                        font
                );

        JButton updateBook =
                createButton(
                        "Update Book",
                        new Color(155, 89, 182),
                        font
                );

        JButton deleteBook =
                createButton(
                        "Delete Book",
                        new Color(231, 76, 60),
                        font
                );

        JButton issueBook =
                createButton(
                        "Issue Book",
                        new Color(26, 188, 156),
                        font
                );

        JButton returnBook =
                createButton(
                        "Return Book",
                        new Color(230, 126, 34),
                        font
                );

        JButton recordBook =
                createButton(
                        "Record",
                        new Color(52, 73, 94),
                        font
                );

        JButton viewMembers =
                createButton(
                        "View Members",
                        new Color(41, 128, 185),
                        font
                );

        JButton logout =
                createButton(
                        "Logout",
                        new Color(192, 57, 43),
                        font
                );

        // ================= BUTTON POSITIONS =================

        addBook.setBounds(70, 100, 220, 70);

        viewBook.setBounds(390, 100, 220, 70);

        searchBook.setBounds(710, 100, 220, 70);

        updateBook.setBounds(70, 220, 220, 70);

        deleteBook.setBounds(390, 220, 220, 70);

        issueBook.setBounds(710, 220, 220, 70);

        returnBook.setBounds(70, 340, 220, 70);

        recordBook.setBounds(390, 340, 220, 70);

        viewMembers.setBounds(710, 340, 220, 70);

        // LOGOUT BUTTON IN CENTER AT LAST
        logout.setBounds(390, 500, 220, 70);

        // ================= ACTIONS =================

        addBook.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(
                    java.awt.event.ActionEvent e
            ) {

                new AddBookScreen();
            }
        });

        viewBook.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(
                    java.awt.event.ActionEvent e
            ) {

                new ViewBooksScreen();
            }
        });

        searchBook.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(
                    java.awt.event.ActionEvent e
            ) {

                new SearchBookScreen();
            }
        });

        updateBook.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(
                    java.awt.event.ActionEvent e
            ) {

                new UpdateBookScreen();
            }
        });

        deleteBook.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(
                    java.awt.event.ActionEvent e
            ) {

                new DeleteBookScreen();
            }
        });

        issueBook.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(
                    java.awt.event.ActionEvent e
            ) {

                new IssueBookScreen();
            }
        });

        returnBook.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(
                    java.awt.event.ActionEvent e
            ) {

                new ReturnBookScreen();
            }
        });

        recordBook.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(
                    java.awt.event.ActionEvent e
            ) {

                new RecordScreen();
            }
        });

        viewMembers.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(
                    java.awt.event.ActionEvent e
            ) {

                new ViewMembersScreen();
            }
        });

        logout.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(
                    java.awt.event.ActionEvent e
            ) {

                dispose();

                new LoginScreen();
            }
        });

        // ================= ADD BUTTONS =================

        panel.add(addBook);

        panel.add(viewBook);

        panel.add(searchBook);

        panel.add(updateBook);

        panel.add(deleteBook);

        panel.add(issueBook);

        panel.add(returnBook);

        panel.add(recordBook);

        panel.add(viewMembers);

        panel.add(logout);

        add(panel);

        setVisible(true);
    }

    // ================= BUTTON STYLE =================

    private JButton createButton(
            String text,
            Color color,
            Font font
    ) {

        JButton btn = new JButton(text);

        btn.setBackground(color);

        btn.setForeground(Color.WHITE);

        btn.setFont(font);

        btn.setFocusPainted(false);

        btn.setBorder(
                BorderFactory.createLineBorder(
                        Color.WHITE,
                        2
                )
        );

        return btn;
    }
}