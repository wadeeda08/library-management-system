/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.gui;
import javax.swing.*;
/**
 *
 * @author unknown
 */
public class MemberSearchBookScreen extends JFrame {

    public MemberSearchBookScreen() {

        String id = JOptionPane.showInputDialog("Enter Book ID:");

        if (id == null) return;

        if (id.equals("101")) {

            JOptionPane.showMessageDialog(null,
                    "📚 BOOK DETAILS\n\n" +
                    "🆔 ID: 101\n" +
                    "📘 Java Programming\n" +
                    "👨‍🏫 James Gosling\n" +
                    "📊 Status: Available"
            );

        } else if (id.equals("102")) {

            JOptionPane.showMessageDialog(null,
                    "📚 BOOK DETAILS\n\n" +
                    "🆔 ID: 102\n" +
                    "📘 Data Structures\n" +
                    "👨‍🏫 Mark Allen Weiss\n" +
                    "📊 Status: Issued"
            );

        } else {

            JOptionPane.showMessageDialog(null,
                    "❌ BOOK NOT FOUND\nTry: 101, 102, 103"
            );
        }

        dispose();
    }
}