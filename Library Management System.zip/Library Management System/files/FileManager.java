/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.files;
import java.io.*;
import java.util.*;

/**
 *
 * @author unknown
 */
public class FileManager {

    public static void write(String file, String data){

        try{
            FileWriter fw = new FileWriter(file,true);
            fw.write(data+"\n");
            fw.close();
        }catch(Exception e){}
    }

    public static String read(String file){

        StringBuilder sb = new StringBuilder();

        try{
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            while((line = br.readLine()) != null){
                sb.append(line).append("\n");
            }

            br.close();

        }catch(Exception e){}

        return sb.toString();
    }
}